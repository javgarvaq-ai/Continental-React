import { Navigate } from 'react-router-dom'

function AuthRoute({ children }) {
    const storedUser = localStorage.getItem('continentalCurrentUser')

    if (!storedUser) {
        return <Navigate to="/login" replace />
    }

    return children
}

export default AuthRoute